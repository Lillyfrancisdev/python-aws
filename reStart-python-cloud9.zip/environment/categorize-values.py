print('Exercise 1: Creating a mixed-type list')

print('')

myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
    
print('')
    
print('Lilly code!')
    
name = input('What is you name?')
school = input('What are you doing?')
    
print('My name is {} I am at {} School!'.format(name,school))
    