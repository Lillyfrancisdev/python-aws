print('Hello, World')
print('I am learning Python')

name1 = input('what is your name?')
print(f'Nice to meet you {name1}')


