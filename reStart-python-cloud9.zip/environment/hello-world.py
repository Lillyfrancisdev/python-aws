
print('My first python code!')
print('')
print("HELLO, WORLD!")
